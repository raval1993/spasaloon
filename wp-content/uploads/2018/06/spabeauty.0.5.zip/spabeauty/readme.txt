=================
Spabeauty THEME
=================
Contributors: themeicy
Tags: three-columns, left-sidebar, right-sidebar, custom-colors, custom-logo, featured-images, full-width-template, threaded-comments, blog, e-commerce, entertainment, food-and-drink, news
Requires at least: 4.0.5
Tested up to: 4.8.1
Stable tag: 0.5

== Theme License & Copyright ==
Spabeauty is distributed under the terms of the GNU GPL
Spabeauty -Copyright 2017 Spabeauty, themeicy.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.



=================
SHORT DESCRIPTION
=================
spabeauty is a powerful bootstrap Wordpress theme for spa or individuals. spabeauty theme which can be used for web design firms or any other yoga, salons, beauty, health, parlor, online shops, woocommerce, health, digital, medical, clinic, dental, spa, beauty, massage, gym, fitness, trainer, coach, restaurant and any other kind of website purpose. It comes with all features these kind of shop page, blog page, Contact form seven working, custom logo, slides variation, color pallate


===========
ABOUT THEME
=========== 
Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. Spabeauty is a
Cross-Browser Compatible theme that works on All leading web browsers. Spabeauty is easy to use and 
user friendly theme. Spabeauty has boxed and full-width layout feature.
Powerful but simple Spabeauty theme content customized through customizer. to make your site attractive it has two 
widget sections first for �sidebar widget section� and second for �Footer widget section� . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. Spabeauty theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. Spabeauty is a fully woocommerce tested theme. Spabeauty is translation ready theme with WPML compatible & Many More�.

This theme is compatible with Wordpress Version 4.4.2  and above and it supports the new theme customization API (https://codex.wordpress.org/Theme_Customization_API).

Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * Spabeauty is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html

/**** Images Source *****/

============================================
All images use Pixabay
============================================
	/***** Screenshot Image *****/
	Screenshot & Banner Image : CCO by Pixabay dungthuyvunguyen :
	1. https://pixabay.com/en/skincare-coconut-oil-therapy-exotic-2357980/

	
	/*** service ***/
	
	Image : CCO by Pixabay rhythmuswege : - 
	1. https://pixabay.com/en/massage-therapy-spa-relax-massage-1731456/

	Image : CCO by Pixabay Nawalescape : - 
	2. https://pixabay.com/en/wellness-massage-relax-relaxing-285587/

	Image : CCO by Pixabay stevepb  : - 
	3. https://pixabay.com/en/massage-therapy-essential-oils-1612308/

========================================================================================	
--- Version 0.1 ----
1. Relesed

--- Version 0.2 ----
1. Update theme URI.

--- Version 0.3 ----
1. Update template name.

--- Version 0.4 ----
1. Fixed theme review issue.

--- Version 0.5 ----
1. Fixed theme review issue.